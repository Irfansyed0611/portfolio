import type {Metadata} from 'next';
import { Space_Grotesk, JetBrains_Mono } from 'next/font/google';
import './globals.css'; // Global styles

const spaceGrotesk = Space_Grotesk({ subsets: ['latin'], variable: '--font-sans' });
const jetBrainsMono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata: Metadata = {
  title: 'Futuristic Preloader',
  description: 'A sci-fi inspired loading sequence that transitions into an animated hero section.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${spaceGrotesk.variable} ${jetBrainsMono.variable}`}>
      <body className="antialiased font-sans bg-black max-w-[100vw] overflow-x-hidden min-h-screen text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
