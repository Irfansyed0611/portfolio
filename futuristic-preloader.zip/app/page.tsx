'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Loader from '@/components/Loader';
import Hero from '@/components/Hero';

export default function Page() {
  const [progress, setProgress] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    let startTime: number;
    let animationFrameId: number;
    const duration = 10000; // Exact 10 seconds loading

    const animate = (time: number) => {
      if (!startTime) startTime = time;
      const elapsedTime = time - startTime;
      const newProgress = Math.min((elapsedTime / duration) * 100, 100);
      setProgress(newProgress);

      if (newProgress < 100) {
        animationFrameId = requestAnimationFrame(animate);
      }
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrameId);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      const timer = setTimeout(() => {
          setIsLoaded(true);
      }, 800); // Wait 800ms after reaching 100% to let the user see it
      return () => clearTimeout(timer);
    }
  }, [progress]);

  return (
    <main className="relative min-h-screen bg-black text-white w-full h-[100dvh] overflow-hidden flex items-center justify-center">
      <AnimatePresence mode="wait">
        {!isLoaded && (
          <motion.div
            key="loader-overlay"
            exit={{ opacity: 0, scale: 1.1, filter: 'blur(10px)' }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black"
          >
            <Loader progress={progress} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* The Hero component manages its own entrance animations via AnimatePresence / isLoaded */}
      <div className="absolute inset-0 z-0">
         <Hero isLoaded={isLoaded} />
      </div>
    </main>
  );
}
