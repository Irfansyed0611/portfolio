'use client';
import { motion, AnimatePresence } from 'motion/react';
import { useEffect, useState } from 'react';


export default function Loader({ progress }: { progress: number }) {
  const displayProgress = Math.floor(progress);
  const totalSegments = 24;
  const filledSegments = Math.floor((progress / 100) * totalSegments);
  
  return (
    <div className="flex items-center justify-center font-mono text-white select-none w-full max-w-2xl px-4">
      


      {/* Main Bar + Info Card */}
      <div className="flex flex-col gap-6 w-full max-w-[600px]">
          


        {/* The segmented bar container */}
        <div className="flex flex-col gap-2 w-full">
            {/* Top Row */}
            <div className="flex justify-between items-end px-1 border-b border-white/20 pb-1">
                <div className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 bg-white animate-[pulse_1s_ease-in-out_infinite]" />
                    <span className="text-sm sm:text-base font-bold tracking-[0.2em] font-sans uppercase">Loading...</span>
                </div>
                <div className="text-xs font-mono text-white/50 tracking-widest hidden sm:block">
                    {displayProgress.toString().padStart(3, '0')} / 100
                </div>
            </div>

            {/* The Bar */}
            <div className="relative p-1.5 mt-1 border border-white/30 bg-black"
                    style={{
                        clipPath: 'polygon(15px 0, 100% 0, 100% calc(100% - 15px), calc(100% - 15px) 100%, 0 100%, 0 15px)'
                    }}
            >
                {/* Corner Accents */}
                <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-white pointer-events-none" />
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-white pointer-events-none" />

                <div className="flex bg-white/5 p-1.5 sm:p-2 gap-1 sm:gap-1.5 h-10 sm:h-12 w-full relative z-10"
                        style={{ clipPath: 'polygon(10px 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%, 0 10px)' }}
                >
                {Array.from({ length: totalSegments }).map((_, i) => {
                    const isFilled = i < filledSegments;
                    const isCurrent = i === filledSegments && progress < 100;
                    
                    return (
                        <div key={i} className="flex-1 bg-white/10 skew-x-[-20deg] relative overflow-hidden group border-r border-black/50">
                            {isFilled && (
                                <motion.div 
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    className="absolute inset-0 bg-white shadow-[0_0_8px_rgba(255,255,255,0.6)]" 
                                />
                            )}
                            {isCurrent && (
                                <motion.div 
                                    initial={{ x: '-100%' }}
                                    animate={{ x: '100%' }}
                                    transition={{ repeat: Infinity, duration: 0.6, ease: "linear" }}
                                    className="absolute inset-0 bg-white/70"
                                />
                            )}
                        </div>
                    );
                })}
                </div>
            </div>

            {/* Bottom decorative bar */}
            <div className="flex gap-2 items-center mt-2 px-1">
                <div className="h-1 sm:h-1.5 flex-[4] bg-white/40" />
                <div className="h-1 sm:h-1.5 flex-1 bg-white/10" />
                <div className="h-1 sm:h-1.5 w-6 bg-white/60" />
                <div className="h-1 sm:h-1.5 w-2 bg-white" />
                <div className="text-[8px] sm:text-[10px] text-white/50 ml-2 tracking-widest uppercase">
                     SYS_IDLE_0x{displayProgress.toString(16).padStart(2, '0').toUpperCase()}
                </div>
            </div>
        </div>

      </div>
    </div>
  );
}
