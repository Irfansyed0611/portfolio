'use client';
import { motion, useAnimation, useInView } from 'motion/react';
import { useEffect, useRef } from 'react';

function GridFloor() {
  return (
    <div className="absolute inset-x-0 bottom-0 h-[50vh] perspective-[1000px] pointer-events-none z-0">
      <motion.div
        initial={{ opacity: 0, rotateX: 60, y: 100 }}
        animate={{ opacity: 1, rotateX: 60, y: 0 }}
        transition={{ duration: 2.5, ease: "easeOut", delay: 0.5 }}
        className="absolute inset-0 flex items-center justify-center origin-bottom"
      >
        <div className="w-[300vw] h-[200vh] border-[rgba(255,255,255,0.05)] border-[1px] bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px] md:bg-[size:80px_80px] [mask-image:radial-gradient(ellipse_at_center,black_10%,transparent_60%)]" />
      </motion.div>
    </div>
  );
}

export default function Hero({ isLoaded }: { isLoaded: boolean }) {
  if (!isLoaded) return <div className="absolute inset-0 pointer-events-none z-0" />;

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center overflow-hidden bg-[radial-gradient(circle_at_center,rgba(20,20,20,1)_0%,rgba(0,0,0,1)_80%)] text-white">
      
      {/* Background Decor */}
      <GridFloor />
      
      <motion.div
         initial={{ opacity: 0, rotate: -45, scale: 0.5 }}
         animate={{ opacity: 0.1, rotate: 135, scale: 1.5 }}
         transition={{ duration: 30, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
         className="absolute pointer-events-none z-0 w-[800px] h-[800px] border border-white/10 border-dashed rounded-full"
      />

      <div className="relative z-10 flex flex-col items-center text-center max-w-4xl px-4 mt-12 md:mt-0">
        <motion.div
          initial={{ opacity: 0, scale: 0.8, filter: 'blur(10px)', y: 20 }}
          animate={{ opacity: 1, scale: 1, filter: 'blur(0px)', y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
        >
          <div className="flex items-center gap-4 text-emerald-400 font-mono text-xs sm:text-sm tracking-[0.3em] font-bold mb-4 sm:mb-8 justify-center">
             <span className="w-8 sm:w-16 h-[1px] bg-emerald-400/50" />
             SYSTEM ONLINE
             <span className="w-8 sm:w-16 h-[1px] bg-emerald-400/50" />
          </div>
          <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-tighter uppercase leading-none font-sans drop-shadow-[0_0_20px_rgba(255,255,255,0.2)]">
             Aegis Core
          </h1>
        </motion.div>
        
        <motion.div
           initial={{ width: 0, opacity: 0 }}
           animate={{ width: "100%", opacity: 1 }}
           transition={{ duration: 1.5, ease: "easeInOut", delay: 0.6 }}
           className="h-[2px] bg-white/10 my-6 sm:my-10 max-w-2xl w-full relative overflow-hidden"
        >
            <motion.div 
               initial={{ x: '-100%' }}
               animate={{ x: '100%' }}
               transition={{ duration: 2, ease: "linear", repeat: Infinity }}
               className="absolute top-0 left-0 h-full w-1/3 bg-gradient-to-r from-transparent via-white/50 to-transparent"
            />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1 }}
          className="text-neutral-400 font-mono text-sm sm:text-base md:text-lg leading-relaxed max-w-2xl"
        >
          Diagnostic sequences complete. Thermal routing stable. 
          Quantum entangled link active. Secure connection established.
          <br className="hidden sm:block" />
          <span className="text-white mt-4 block">Ready to receive directive from command console.</span>
        </motion.p>
        
        <div className="mt-12 flex flex-col sm:flex-row gap-4 sm:gap-6 w-full sm:w-auto">
            <motion.button
                whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.1)" }}
                whileTap={{ scale: 0.95 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.4 }}
                className="w-full sm:w-auto px-8 py-4 sm:py-5 border border-white/30 font-mono uppercase tracking-[0.2em] text-xs sm:text-sm hover:border-white transition-colors relative group overflow-hidden"
            >
                <div className="absolute inset-0 bg-white translate-y-[100%] group-hover:translate-y-0 transition-transform ease-out duration-300" />
                <span className="relative z-10 group-hover:text-black transition-colors duration-300">Engage Systems</span>
            </motion.button>
            <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.6 }}
                className="w-full sm:w-auto px-8 py-4 sm:py-5 bg-white text-black font-mono font-bold uppercase tracking-[0.2em] text-xs sm:text-sm hover:bg-neutral-200 transition-colors shadow-[0_0_20px_rgba(255,255,255,0.3)]"
            >
                View Diagnostics
            </motion.button>
        </div>
      </div>
    </div>
  );
}
